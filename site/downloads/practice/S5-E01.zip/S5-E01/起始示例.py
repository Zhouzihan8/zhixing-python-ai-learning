d_in,d_out,r=1024,1024,8
print('full',d_in*d_out)
print('lora',r*d_in+d_out*r)
print('ratio',round((r*d_in+d_out*r)/(d_in*d_out),4))