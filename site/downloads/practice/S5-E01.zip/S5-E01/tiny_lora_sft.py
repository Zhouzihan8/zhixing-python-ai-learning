"""Minimal CPU LoRA/SFT mechanics, not a quality finetuning recipe."""
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, TaskType, get_peft_model, PeftModel

torch.manual_seed(7)
MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
base = AutoModelForCausalLM.from_pretrained(MODEL_ID).float().cpu()
base.config.use_cache = False
config = LoraConfig(
    task_type=TaskType.CAUSAL_LM, r=4, lora_alpha=8,
    lora_dropout=0.0, target_modules=["q_proj", "v_proj"],
)
model = get_peft_model(base, config)
model.print_trainable_parameters()
trainable = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
assert trainable and all("lora_" in n for n, _ in trainable)
optimizer = torch.optim.AdamW([p for _, p in trainable], lr=1e-3)
samples = [
    ("Name the Python container mapping keys to values.", "dictionary"),
    ("Name the Python ordered mutable container.", "list"),
]

def make_batch(question, answer):
    prompt = tokenizer.apply_chat_template(
        [{"role": "user", "content": question}],
        tokenize=True, add_generation_prompt=True,
    )
    completion = tokenizer(answer + tokenizer.eos_token,
                           add_special_tokens=False)["input_ids"]
    # Keep prompt positions out of the loss; no padding for batch size 1.
    ids = prompt + completion
    labels = [-100] * len(prompt) + completion
    assert len(ids) < 128 and any(v != -100 for v in labels)
    return {
        "input_ids": torch.tensor([ids]),
        "attention_mask": torch.ones(1, len(ids), dtype=torch.long),
        "labels": torch.tensor([labels]),
    }

before = {n: p.detach().clone() for n, p in trainable}
model.train()
for epoch in range(2):
    for question, answer in samples:
        batch = make_batch(question, answer)
        optimizer.zero_grad()
        result = model(**batch)
        assert torch.isfinite(result.loss), "Loss must be finite."
        result.loss.backward()
        # At initial zero-B initialization, not all LoRA factors need nonzero grad.
        assert any(p.grad is not None and p.grad.abs().sum() > 0
                   for _, p in trainable), "Expected at least one nonzero adapter gradient."
        optimizer.step()
        print("epoch", epoch, "loss", round(result.loss.item(), 4))

changed = any(not torch.equal(before[n], p.detach()) for n, p in trainable)
print("adapter parameter changed:", changed)
assert changed
save_dir = Path("tiny_lora_adapter")
model.save_pretrained(save_dir)
tokenizer.save_pretrained(save_dir)
print("adapter saved to:", save_dir.resolve())

# Reload onto the SAME base-model identifier, then run one real inference.
fresh = AutoModelForCausalLM.from_pretrained(MODEL_ID).float().cpu()
loaded = PeftModel.from_pretrained(fresh, save_dir)
loaded.eval()
question = "Name the Python container mapping keys to values."
prompt = tokenizer.apply_chat_template(
    [{"role": "user", "content": question}],
    tokenize=False, add_generation_prompt=True,
)
inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
with torch.inference_mode():
    generated = loaded.generate(**inputs, do_sample=False, max_new_tokens=12,
                                pad_token_id=tokenizer.eos_token_id)
print("reloaded answer:",
      tokenizer.decode(generated[0, inputs["input_ids"].shape[-1]:],
                       skip_special_tokens=True))
print("Two examples demonstrate the update path, not generalization or quality improvement.")
