import os
import mysql.connector
con=mysql.connector.connect(host=os.environ.get("MYSQL_HOST","127.0.0.1"),
 user=os.environ["MYSQL_USER"],password=os.environ["MYSQL_PASSWORD"],
 database=os.environ["MYSQL_DATABASE"])
cur=con.cursor()
try:
    cur.execute("CREATE TABLE IF NOT EXISTS study_runs (id INTEGER PRIMARY KEY AUTO_INCREMENT, question TEXT NOT NULL, score DOUBLE NOT NULL)")
    cur.execute("INSERT INTO study_runs(question,score) VALUES (%s,%s)",("python",0.8))
    con.commit()
    cur.execute("SELECT id,question,score FROM study_runs WHERE score >= %s ORDER BY score DESC",(0.7,))
    for row in cur:
        print(row)
except Exception:
    con.rollback()
    raise
finally:
    cur.close()
    con.close()
