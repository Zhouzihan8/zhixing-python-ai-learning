import sqlite3
con=sqlite3.connect(":memory:")
con.executescript("CREATE TABLE experiments(id INTEGER PRIMARY KEY, name TEXT); CREATE TABLE runs(experiment_id INTEGER, score REAL); INSERT INTO experiments VALUES(1,'baseline'); INSERT INTO runs VALUES(1,0.8),(1,0.6);")
for name,average in con.execute("SELECT e.name, AVG(r.score) FROM experiments e JOIN runs r ON r.experiment_id=e.id GROUP BY e.id,e.name"):
    print(name,round(average,2))
con.close()
