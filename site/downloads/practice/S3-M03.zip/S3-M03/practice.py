from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier,export_text
from sklearn.ensemble import RandomForestClassifier
X,y=load_iris(return_X_y=True)
a,b,c,d=train_test_split(X,y,stratify=y,random_state=7)
for depth in [1,3,None]:
    model=DecisionTreeClassifier(max_depth=depth,random_state=7).fit(a,c)
    print("depth",depth,"train",model.score(a,c),"test",model.score(b,d))
forest=RandomForestClassifier(n_estimators=100,random_state=7).fit(a,c)
print("forest",forest.score(b,d))
print(export_text(DecisionTreeClassifier(max_depth=2,random_state=7).fit(a,c)))
