for length in [20,80,160]:
    print(length,"短文本" if length<=60 else "长文本")
