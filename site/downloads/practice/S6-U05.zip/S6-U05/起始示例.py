def average(total, count):
    if count <= 0:
        raise ValueError("count 必须大于 0")
    return total / count

tools = {"average": average}
call = {"name":"average","arguments":{"total":240,"count":3}}
name = call["name"]
if name not in tools:
    print("未知工具")
else:
    try:
        value = tools[name](**call["arguments"])
        print("工具结果:", value)
    except (TypeError, ValueError) as error:
        print("执行失败:", error)
