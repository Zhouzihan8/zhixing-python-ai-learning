rows=[{'name':'A','words':10},{'name':'B','words':None},{'name':'C','words':0}]
valid=[r for r in rows if r['words'] is not None]
print(len(rows),len(valid))
print(sum(r['words'] for r in valid))