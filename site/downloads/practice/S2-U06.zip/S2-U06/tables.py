from io import StringIO
from pathlib import Path
import pandas as pd

csv_text = "name,category,words\nA,AI,10\nB,AI,\nC,Python,0\nA,AI,10\nD,AI,5\n"
source = pd.read_csv(StringIO(csv_text))
print("input shape:", source.shape)
print("missing:\n", source.isna().sum())
# Here identical name/category/words rows represent accidental duplicate records.
deduplicated = source.drop_duplicates(subset=["name", "category", "words"])
clean = deduplicated[deduplicated["words"].notna()].copy()
clean["words"] = clean["words"].astype("int64")
summary = clean.groupby("category").agg(
    documents=("name", "size"), total_words=("words", "sum"))
out = Path("results")
out.mkdir(exist_ok=True)
clean.to_csv(out / "clean.csv", index=False)
summary.to_csv(out / "summary.csv")
print(summary)
assert len(clean) == 3
assert summary.loc["AI", "total_words"] == 15
assert summary.loc["Python", "documents"] == 1
