cases = [
    {"id":"q1","gold":{"c1"},"retrieved":["c1","c2"],"correct":True},
    {"id":"q2","gold":{"c3"},"retrieved":["c2","c4"],"correct":False},
    {"id":"q3","gold":{"c5"},"retrieved":["c5","c6"],"correct":False},
]
hits = sum(bool(c["gold"] & set(c["retrieved"])) for c in cases)
correct = sum(c["correct"] for c in cases)
print(f"检索命中: {hits}/{len(cases)}")
print(f"回答正确: {correct}/{len(cases)}")
