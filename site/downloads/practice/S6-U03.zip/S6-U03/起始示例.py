docs = [
    {"id": "c1", "source": "notes.md", "text": "列表 copy 创建浅拷贝"},
    {"id": "c2", "source": "loops.md", "text": "for 循环遍历元素"},
]
question = "copy"
hits = [doc for doc in docs if question in doc["text"]]
if not hits:
    print("资料不足")
else:
    doc = hits[0]
    print(doc["text"])
    print("依据:", doc["id"], doc["source"])
