class Document:
    def __init__(self, title, text):
        self.title = title
        self.text = text
    def words(self):
        return len(self.text.split())
a = Document('A', 'python ai')
b = Document('B', 'python')
print(a.words(), b.words())