import math
scores=[2.0,1.0,0.0]
shift=max(scores)
exps=[math.exp(x-shift) for x in scores]
probs=[x/sum(exps) for x in exps]
print([round(x,3) for x in probs])
print(round(-math.log(probs[0]),3))