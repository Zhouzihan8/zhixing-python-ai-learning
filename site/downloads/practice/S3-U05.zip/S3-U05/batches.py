import torch
from torch.utils.data import Dataset, DataLoader

class TinyDataset(Dataset):
    def __init__(self):
        self.features = torch.tensor([[1.,0.],[0.,1.],[1.,1.]])
        self.labels = torch.tensor([0,1,0], dtype=torch.long)
    def __len__(self):
        return len(self.labels)
    def __getitem__(self, index):
        return self.features[index], self.labels[index]

loader = DataLoader(TinyDataset(), batch_size=2, shuffle=False)
for features, labels in loader:
    print("batch:", tuple(features.shape), tuple(labels.shape))
logits = torch.tensor([[2.,1.,0.],[0.,1.,2.]])
labels = torch.tensor([0,2], dtype=torch.long)
loss = torch.nn.CrossEntropyLoss()(logits, labels)
print("loss:", loss.item())
print("predictions:", logits.argmax(dim=1))
