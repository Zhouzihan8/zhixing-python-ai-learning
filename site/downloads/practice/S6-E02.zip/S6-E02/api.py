from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI()

class CountRequest(BaseModel):
    text: str = Field(min_length=1)

@app.post("/count")
def count_words(request: CountRequest):
    counts = {}
    for word in request.text.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return {"counts": counts}
