text = "Python AI Python"
counts = {}
for word in text.lower().split():
    counts[word] = counts.get(word, 0) + 1
print({"counts": counts})
