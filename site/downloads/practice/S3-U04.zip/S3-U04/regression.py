import torch

torch.manual_seed(7)
x = torch.tensor([[1.], [2.], [3.]])
y = 2 * x
model = torch.nn.Linear(1, 1, bias=False)
optimizer = torch.optim.SGD(model.parameters(), lr=0.05)
loss_fn = torch.nn.MSELoss()
for step in range(30):
    optimizer.zero_grad()
    prediction = model(x)
    loss = loss_fn(prediction, y)
    loss.backward()
    optimizer.step()
    if step in (0, 9, 29):
        print(step + 1, "loss", loss.item())
model.eval()
with torch.no_grad():
    print("weight:", model.weight.item())
    print("prediction for x=4:", model(torch.tensor([[4.]])).item())
