xs=[1.,2.,3.]
ys=[2.,4.,6.]
w=0.0
for epoch in range(20):
    grad=sum(2*(w*x-y)*x for x,y in zip(xs,ys))/len(xs)
    w-=0.05*grad
print(round(w,3))
print(round(w*4,3))