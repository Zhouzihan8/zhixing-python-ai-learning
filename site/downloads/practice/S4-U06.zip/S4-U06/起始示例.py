import math
def attend(values,t):
    allowed=values[:t+1]
    scores=[values[t]*x for x in allowed]
    e=[math.exp(s-max(scores)) for s in scores]
    return sum(a*b for a,b in zip(e,allowed))/sum(e)
a=[1.0,2.0,3.0]
b=[1.0,2.0,99.0]
print([round(attend(a,t),4) for t in range(2)])
print([round(attend(b,t),4) for t in range(2)])