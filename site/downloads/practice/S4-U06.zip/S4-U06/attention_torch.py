"""CPU attention experiment: no dataset or model download."""
import math
import torch
from torch.nn import functional as F

torch.manual_seed(7)
# B=batch, H=heads, T=sequence length, D=per-head width.
B, H, T, D = 1, 2, 3, 2
q = torch.randn(B, H, T, D)
k = torch.randn(B, H, T, D)
v = torch.randn(B, H, T, D)

# [T,T], True means KEEP for F.scaled_dot_product_attention.
# Rows=query positions, columns=key positions; include diagonal.
keep = torch.ones(T, T, dtype=torch.bool).tril()
# [B,H,T,T]; [T,T] mask broadcasts over B,H.
scores = q @ k.transpose(-2, -1) / math.sqrt(D)
weights = scores.masked_fill(~keep, float("-inf")).softmax(dim=-1)
manual = weights @ v                       # [B,H,T,D]
actual = F.scaled_dot_product_attention(
    q, k, v, attn_mask=keep, dropout_p=0.0
)
torch.testing.assert_close(actual, manual)
print("Q shape:", tuple(q.shape))
print("mask shape:", tuple(keep.shape))
print("output shape:", tuple(actual.shape))
print("keep mask:\n", keep.int())
print("first-head weights:\n", weights[0, 0])

# Change only the future VALUE position, leaving q,k unchanged.
changed_v = v.clone()
changed_v[:, :, 2, :] += 100.0
changed = F.scaled_dot_product_attention(
    q, k, changed_v, attn_mask=keep, dropout_p=0.0
)
past_delta = (changed[:, :, :2, :] - actual[:, :, :2, :]).abs().max()
last_delta = (changed[:, :, 2, :] - actual[:, :, 2, :]).abs().max()
print("causal past max change:", past_delta.item())
print("causal last max change:", last_delta.item())
torch.testing.assert_close(changed[:, :, :2, :], actual[:, :, :2, :])

# Same data without a causal mask: past can now read the changed value.
unmasked = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
unmasked_changed = F.scaled_dot_product_attention(q, k, changed_v, dropout_p=0.0)
print("unmasked past max change:",
      (unmasked_changed[:, :, :2, :] - unmasked[:, :, :2, :]).abs().max().item())
print("manual and framework calculations agree.")
