values=[-2.,-0.5,0.,1.,3.]
relu=[max(0.,x) for x in values]
print(relu)