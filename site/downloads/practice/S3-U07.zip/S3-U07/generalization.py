import torch

torch.manual_seed(7)
model = torch.nn.Sequential(
    torch.nn.Linear(2, 8), torch.nn.ReLU(),
    torch.nn.Dropout(0.5), torch.nn.Linear(8, 2))
x = torch.ones(12, 2)
model.train()
first, second = model(x), model(x)
print("training forwards equal:", torch.allclose(first, second))
model.eval()
with torch.no_grad():
    first, second = model(x), model(x)
print("evaluation forwards equal:", torch.allclose(first, second))
print("shape:", tuple(first.shape))
optimizer = torch.optim.SGD(model.parameters(), lr=0.05, weight_decay=0.001)
print("optimizer:", type(optimizer).__name__)
