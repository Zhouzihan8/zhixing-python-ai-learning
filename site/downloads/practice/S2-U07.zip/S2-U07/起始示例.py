labels=['Python','AI','Math']
values=[12,8,10]
pairs=sorted(zip(labels,values),key=lambda pair:pair[1],reverse=True)
for label,value in pairs:
    print(label,value)