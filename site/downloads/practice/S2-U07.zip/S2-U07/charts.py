from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

pairs = [("Python", 12), ("AI", 8), ("Math", 10)]
ordered = sorted(pairs, key=lambda pair: pair[1], reverse=True)
labels = [label for label, _ in ordered]
counts = [value for _, value in ordered]
out = Path("results")
out.mkdir(exist_ok=True)
fig, ax = plt.subplots(figsize=(6, 4))
ax.bar(labels, counts, color="#20645d")
ax.set(title="Words by category", xlabel="Category", ylabel="Word count")
ax.set_ylim(bottom=0)
fig.tight_layout()
fig.savefig(out / "word_counts.png", dpi=160)
plt.close(fig)
epochs = [1, 2, 3, 4]
train = [0.9, 0.6, 0.4, 0.2]
valid = [1.0, 0.7, 0.6, 0.8]
fig, ax = plt.subplots(figsize=(6, 4))
ax.plot(epochs, train, marker="o", label="train")
ax.plot(epochs, valid, marker="o", label="validation")
ax.set(xlabel="Epoch", ylabel="Loss", title="Illustrative learning curves")
ax.legend()
fig.tight_layout()
fig.savefig(out / "learning_curves.png", dpi=160)
plt.close(fig)
print("Saved: results/word_counts.png")
print("Saved: results/learning_curves.png")
