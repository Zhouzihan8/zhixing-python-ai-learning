import json
allowed={'正面','负面','中性'}
outputs=['{"label":"正面"}','{"label":"开心"}','not json']
for raw in outputs:
    try:
        value=json.loads(raw)
        print('合法标签' if isinstance(value,dict) and value.get('label') in allowed else '标签无效')
    except json.JSONDecodeError:
        print('JSON无效')