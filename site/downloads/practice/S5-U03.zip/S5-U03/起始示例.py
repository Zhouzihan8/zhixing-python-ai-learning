import math
def softmax(scores,t):
    z=[s/t for s in scores]
    e=[math.exp(s-max(z)) for s in z]
    return [round(x/sum(e),4) for x in e]
print(softmax([1,2,3],0.5))
print(softmax([1,2,3],2.0))