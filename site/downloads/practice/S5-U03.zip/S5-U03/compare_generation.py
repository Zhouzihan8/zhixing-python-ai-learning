import json
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"
# Teaching model primarily supports English; use English to isolate interface learning.
torch.manual_seed(7)
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
# Default local device is CPU; .float() makes subsequent CPU operations float32.
model = AutoModelForCausalLM.from_pretrained(MODEL_ID).float().cpu()
model.eval()
if tokenizer.pad_token_id is None:
    tokenizer.pad_token = tokenizer.eos_token

def encode_question(text):
    messages = [{"role": "user", "content": text}]
    # Template inserts the model's role/special markers.
    rendered = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    # Do not add a second set of special tokens after rendering the template.
    batch = tokenizer(rendered, return_tensors="pt", add_special_tokens=False)
    return rendered, batch

def generate_answer(text, max_new_tokens=32, **sampling):
    _, batch = encode_question(text)
    with torch.inference_mode():
        output = model.generate(
            **batch, max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.pad_token_id, **sampling
        )
    # The returned sequence includes the prompt: decode only the new suffix.
    suffix = output[0, batch["input_ids"].shape[-1]:]
    return tokenizer.decode(suffix, skip_special_tokens=True)

question = "Give one practical use of a Python dictionary."
_, batch = encode_question(question)
used = batch["input_ids"].shape[-1]
limit = model.config.max_position_embeddings
print("input tokens:", used, "model configured position limit:", limit)
print("input plus requested output:", used + 32)
print("greedy:", generate_answer(question, do_sample=False))
# This is a comparison of sampling settings, not a claim about factual quality.
for temperature in [0.5, 1.2]:
    torch.manual_seed(7)
    answer = generate_answer(
        question, do_sample=True, temperature=temperature, top_p=0.9
    )
    print("temperature", temperature, ":", answer)
