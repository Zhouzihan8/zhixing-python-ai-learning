from pathlib import Path
text = Path("sample.txt").read_text(encoding="utf-8")
counts = {}
for word in text.lower().split():
    counts[word] = counts.get(word, 0) + 1
print(counts)
