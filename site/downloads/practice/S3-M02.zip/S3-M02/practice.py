from sklearn.datasets import make_regression,load_iris
from sklearn.linear_model import LinearRegression,LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
X,y=make_regression(n_samples=100,n_features=2,noise=10,random_state=7)
a,b,c,d=train_test_split(X,y,random_state=7)
model=LinearRegression().fit(a,c)
print("回归留出R²",model.score(b,d),"系数",model.coef_)
X,y=load_iris(return_X_y=True);X=X[y<2];y=y[y<2]
a,b,c,d=train_test_split(X,y,stratify=y,random_state=7)
pipe=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=500))
pipe.fit(a,c)
print("分类留出准确率",pipe.score(b,d))
print("前两条概率",pipe.predict_proba(b[:2]))
