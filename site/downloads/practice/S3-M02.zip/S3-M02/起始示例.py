import math
for z in [-2,0,2]:
    print(round(1/(1+math.exp(-z)),3))
