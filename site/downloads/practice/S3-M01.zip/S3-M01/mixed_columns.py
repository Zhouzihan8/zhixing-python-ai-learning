"""数值补缺、类别编码、Pipeline；在安装 scikit-learn 后运行。"""
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# 每行：[长度, 类型]；目标标签单独保存，不属于输入列。
X_train = np.array([[100, "教程"], [None, "论文"], [300, "教程"],
                    [800, "论文"], [900, "新闻"], [200, "新闻"]], dtype=object)
y_train = [0, 0, 0, 1, 1, 0]
X_new = np.array([[None, "教程"], [700, "笔记"]], dtype=object)

numeric = Pipeline([
    ("fill", SimpleImputer(missing_values=None, strategy="mean")),
    ("scale", StandardScaler()),
])
preprocess = ColumnTransformer([
    ("numeric", numeric, [0]),
    ("category", OneHotEncoder(handle_unknown="ignore"), [1]),
])
model = Pipeline([("prepare", preprocess), ("model", LogisticRegression())])
model.fit(X_train, y_train)
print("训练列均值:", model.named_steps["prepare"].named_transformers_["numeric"].named_steps["fill"].statistics_)
print("新数据预测:", model.predict(X_new))
print("正类概率:", model.predict_proba(X_new)[:, 1])
# “笔记”未在训练中出现，其独热编码全为零。用新样本重新 fit 会改变规则，不能这样做。
