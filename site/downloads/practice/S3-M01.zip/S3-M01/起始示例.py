train = [10, 20, 30]
mean = sum(train) / len(train)
print(mean)
print(100 - mean)
