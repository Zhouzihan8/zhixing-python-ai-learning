from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
X,y=load_iris(return_X_y=True)
X_train,X_test,y_train,y_test=train_test_split(X,y,stratify=y,random_state=7)
pipe=make_pipeline(StandardScaler(),LogisticRegression(max_iter=500))
pipe.fit(X_train,y_train)
print("留出集准确率",pipe.score(X_test,y_test))
