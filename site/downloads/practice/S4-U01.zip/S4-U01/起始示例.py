ids = [2, 3, 2, 4]
print('input', ids[:-1])
print('target', ids[1:])