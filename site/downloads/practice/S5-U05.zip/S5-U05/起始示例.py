gold={'a':'正面','b':'负面','c':'中性','d':'正面'}
pred={'a':'正面','b':None,'c':'中性','d':'负面'}
correct=sum(pred.get(k)==v for k,v in gold.items())
valid=sum(pred.get(k) in {'正面','负面','中性'} for k in gold)
print(f'correct={correct}/{len(gold)}')
print(f'valid={valid}/{len(gold)}')