import json
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"
# Teaching model primarily supports English; use English to isolate interface learning.
torch.manual_seed(7)
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
# Default local device is CPU; .float() makes subsequent CPU operations float32.
model = AutoModelForCausalLM.from_pretrained(MODEL_ID).float().cpu()
model.eval()
if tokenizer.pad_token_id is None:
    tokenizer.pad_token = tokenizer.eos_token

def encode_question(text):
    messages = [{"role": "user", "content": text}]
    # Template inserts the model's role/special markers.
    rendered = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    # Do not add a second set of special tokens after rendering the template.
    batch = tokenizer(rendered, return_tensors="pt", add_special_tokens=False)
    return rendered, batch

def generate_answer(text, max_new_tokens=32, **sampling):
    _, batch = encode_question(text)
    with torch.inference_mode():
        output = model.generate(
            **batch, max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.pad_token_id, **sampling
        )
    # The returned sequence includes the prompt: decode only the new suffix.
    suffix = output[0, batch["input_ids"].shape[-1]:]
    return tokenizer.decode(suffix, skip_special_tokens=True)

samples = [
    {"id": "a", "text": "The product works well.", "gold": "positive"},
    {"id": "b", "text": "It broke on the first day.", "gold": "negative"},
    {"id": "c", "text": "The box is white.", "gold": "neutral"},
]
allowed = {"positive", "negative", "neutral"}
results = []
for row in samples:
    question = (
        "Classify the sentiment as positive, negative, or neutral. "
        "Reply with only one label. Review: " + row["text"]
    )
    raw = generate_answer(question, max_new_tokens=12, do_sample=False)
    label = raw.strip().lower()
    valid = label in allowed
    results.append({
        "id": row["id"], "gold": row["gold"], "raw": raw,
        "prediction": label if valid else None,
        "valid": valid, "correct": valid and label == row["gold"],
    })
target = Path("real_results.jsonl")
target.write_text(
    "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in results),
    encoding="utf-8",
)
print("written:", target.resolve())
print("valid:", sum(r["valid"] for r in results), "/", len(results))
print("correct:", sum(r["correct"] for r in results), "/", len(results))
for row in results:
    print(row)
