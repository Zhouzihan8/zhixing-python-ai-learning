import json
samples=[{'id':'a','text':'很好用','label':'正面'},{'id':'b','text':'无法启动','label':'负面'}]
def demo_predict(text):
    return {'很好用':'正面','无法启动':'负面'}.get(text,'中性')
rows=[]
for s in samples:
    prediction=demo_predict(s['text'])
    rows.append({'id':s['id'],'prediction':prediction,'correct':prediction==s['label']})
print(json.dumps(rows,ensure_ascii=False))
print('accuracy',sum(r['correct'] for r in rows)/len(rows))