words = "Python AI Python".split()
print(words)
print(words[:2])
