minutes = int(input("分钟："))
print(f"合计 {minutes + 10} 分钟")
