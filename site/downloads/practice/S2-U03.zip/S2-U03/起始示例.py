import sys
from pathlib import Path
print('Python', sys.version_info.major)
print('当前目录存在:', Path.cwd().is_dir())