memory = {"style": "先例子后原理"}
state = {"last_tool_result": "浅拷贝内部对象仍可能共享"}
question = "请解释浅拷贝"
context = [
    "回答风格: " + memory["style"],
    "问题: " + question,
    "工具结果: " + state["last_tool_result"],
]
print("\n".join(context))
