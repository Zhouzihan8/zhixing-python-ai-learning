"""真实工具执行 + 明确标记的规则策略；没有调用语言模型。"""
import argparse
import json
from pathlib import Path

DOCUMENTS = [
    {"id": "copy-1", "source": "notes/copy.md", "text": "浅拷贝只复制外层容器 内部对象仍可能共享"},
    {"id": "loop-1", "source": "notes/loop.md", "text": "for 循环遍历元素"},
]

def search(query):
    # 词面匹配示例，不是 embedding 检索。
    return [doc for doc in DOCUMENTS if query in doc["text"]]

def count_words(text):
    return len(text.split())

def execute(action):
    name = action.get("name")
    args = action.get("arguments", {})
    if name == "search":
        query = args.get("query")
        if not isinstance(query, str) or not query.strip():
            raise ValueError("query 必须是非空字符串")
        return search(query)
    if name == "count_words":
        text = args.get("text")
        if not isinstance(text, str):
            raise ValueError("text 必须是字符串")
        return count_words(text)
    raise ValueError("未知工具: " + str(name))

def decide(state):
    """规则控制器，只解决“搜索关键词后计算命中片段词数”这个固定任务。"""
    observations = state["observations"]
    if not observations:
        return {"type": "tool", "name": "search", "arguments": {"query": state["query"]}}
    if len(observations) == 1:
        hits = observations[0]["result"]
        if not hits:
            return {"type": "final", "text": "资料不足，没有找到相关片段。"}
        return {"type": "tool", "name": "count_words", "arguments": {"text": hits[0]["text"]}}
    first_hit = observations[0]["result"][0]
    count = observations[1]["result"]
    return {"type": "final", "text": f"{first_hit['text']} [{first_hit['id']}]；按空格分词共 {count} 项。"}

def run(query, max_steps):
    state = {"query": query, "observations": [], "trace": [], "answer": None, "stop_reason": None}
    for step in range(1, max_steps + 1):
        action = decide(state)
        event = {"step": step, "action": action}
        if action.get("type") == "final":
            state["answer"] = action["text"]
            state["stop_reason"] = "final"
            state["trace"].append(event)
            break
        if action.get("type") != "tool":
            event["error"] = "未知动作类型"
            state["trace"].append(event)
            state["stop_reason"] = "invalid_action"
            break
        try:
            result = execute(action)
        except (ValueError, TypeError) as error:
            event["error"] = str(error)
            state["trace"].append(event)
            state["stop_reason"] = "tool_error"
            break
        event["result"] = result
        state["observations"].append({"name": action["name"], "result": result})
        state["trace"].append(event)
    else:
        state["stop_reason"] = "step_budget"
    return state

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", default="浅拷贝")
    parser.add_argument("--max-steps", type=int, default=3)
    args = parser.parse_args()
    if args.max_steps < 1:
        parser.error("--max-steps must be positive")
    result = run(args.query, args.max_steps)
    output = Path(__file__).resolve().parent / "agent_trace.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("模式: rule_policy_demo（规则决策；真实执行 Python 工具）")
    for event in result["trace"]:
        print(json.dumps(event, ensure_ascii=False))
    print("停止原因:", result["stop_reason"])
    print("答案:", result["answer"] or "未形成最终答案")
    print("日志:", output.name)
