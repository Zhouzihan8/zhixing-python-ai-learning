tools = {"double": lambda value: value * 2}
actions = [
    {"type":"tool","name":"double","arguments":{"value":6}},
    {"type":"final","text":"已根据工具结果完成。"},
]
observations = []
max_steps = 3
for step, action in enumerate(actions[:max_steps], start=1):
    if action["type"] == "final":
        print("结束:", action["text"])
        break
    result = tools[action["name"]](**action["arguments"])
    observations.append(result)
    print("步骤", step, "工具结果", result)
else:
    print("结束: 尚无最终答案")
print("观察:", observations)
