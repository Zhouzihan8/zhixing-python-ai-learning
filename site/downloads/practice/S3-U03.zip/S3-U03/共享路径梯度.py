"""对照 micrograd 的标量计算图思想手算，不实现自动求导引擎。"""
x = 2.0
u = x * x
y = u + x
via_u = 2 * x
via_direct = 1.0
total = via_u + via_direct
eps = 1e-6
f = lambda t: t*t+t
numerical = (f(x+eps)-f(x-eps))/(2*eps)
print("前向：",u,y)
print("两条路径：",via_u,via_direct,"相加：",total)
print("有限差分：",round(numerical,6))
assert abs(total-numerical) < 1e-6
