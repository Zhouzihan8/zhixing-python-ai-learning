x,target,w,lr=2.0,6.0,1.0,0.05
prediction=w*x
loss=(prediction-target)**2
grad=2*(prediction-target)*x
print(loss,grad)
w=w-lr*grad
print(round(w,2))