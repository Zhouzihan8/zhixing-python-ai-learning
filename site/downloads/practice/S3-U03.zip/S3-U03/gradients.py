import torch

w = torch.tensor(1.0, requires_grad=True)
loss = (w * 2 - 6) ** 2
loss.backward()
print("loss:", loss.item())
print("gradient:", w.grad.item())
assert torch.allclose(w.grad, torch.tensor(-16.))
with torch.no_grad():
    w -= 0.05 * w.grad
print("updated weight:", w.item())
w.grad = None
next_loss = (w * 2 - 6) ** 2
next_loss.backward()
print("new gradient:", w.grad.item())
