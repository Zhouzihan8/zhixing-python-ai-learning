def fold(values):
    h = 0
    for x in values:
        h = 0.5 * h + x
    return h
print(fold([1, 2, 3]))
print(fold([3, 2, 1]))