import textstats
print(textstats.count_words("Python AI Python"))
