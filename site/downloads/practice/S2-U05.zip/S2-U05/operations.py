import numpy as np

x = np.array([[1., 2.], [3., 4.], [5., 6.]])
offset = np.array([10., 20.])
print("broadcast:\n", x + offset)
print("sum over samples:", x.sum(axis=0))
print("sum over features:", x.sum(axis=1))
print("keepdims shape:", x.sum(axis=1, keepdims=True).shape)
w = np.array([[1., 0., 2.], [0., 1., 3.]])
prediction = x @ w
print("matrix product shape:", prediction.shape)
print("first output:", prediction[0])
print("elementwise square:\n", x * x)
loop = np.array([[sum(row[k] * w[k, j] for k in range(2))
                  for j in range(3)] for row in x])
assert np.allclose(prediction, loop)
assert prediction.shape == (3, 3)
