a = [[1,2,3],[4,5,6]]
row_sums = [sum(row) for row in a]
column_sums = [sum(column) for column in zip(*a)]
print(row_sums)
print(column_sums)