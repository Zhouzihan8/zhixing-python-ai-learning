import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE runs (id INTEGER PRIMARY KEY, question TEXT, score REAL)")
con.executemany("INSERT INTO runs(question, score) VALUES (?, ?)", [("python", 0.8), ("attention", 0.6)])
con.commit()
for row in con.execute("SELECT question, score FROM runs WHERE score >= ? ORDER BY score DESC", (0.7,)):
    print(row[0], row[1])
con.close()
