counts = {"python": 2, "ai": 1, "model": 2}
rows = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
for rank, (word, count) in enumerate(rows, start=1):
    print(rank, word, count)
