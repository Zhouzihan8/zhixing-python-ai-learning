phases=[('pretrain',True),('SFT',True),('inference',False)]
for name,updates in phases:
    print(name, '更新参数' if updates else '使用固定参数')