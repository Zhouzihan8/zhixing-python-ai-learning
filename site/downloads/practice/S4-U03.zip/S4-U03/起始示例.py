import math
q = [1.0, 0.0]
keys = [[1.0, 0.0], [0.0, 1.0]]
values = [[10.0, 0.0], [0.0, 20.0]]
scores = [sum(a*b for a,b in zip(q,k))/math.sqrt(2) for k in keys]
e = [math.exp(s-max(scores)) for s in scores]
w = [x/sum(e) for x in e]
y = [sum(wi*v[j] for wi,v in zip(w,values)) for j in range(2)]
print([round(x,4) for x in w])
print([round(x,4) for x in y])