def clean(rows):
    return [r for r in rows if r['words'] is not None and r['words']>=0]
def summarize(rows):
    result={}
    for row in rows:
        key=row['category']
        result[key]=result.get(key,0)+row['words']
    return result
rows=[{'category':'AI','words':10},{'category':'AI','words':None},{'category':'Python','words':0}]
print(summarize(clean(rows)))