from io import StringIO
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def read_records():
    return pd.read_csv(StringIO(
        "name,category,words\nA,AI,10\nB,AI,\nC,Python,0\nD,AI,5\n"))

def clean_records(source):
    return source[source["words"].notna() & (source["words"] >= 0)].copy()

def summarize(clean):
    return clean.groupby("category").agg(
        documents=("name", "size"), words=("words", "sum"))

def save_results(summary, count, output):
    output.mkdir(exist_ok=True)
    summary.to_csv(output / "summary.csv")
    report = {"valid_records": count,
              "total_words": float(summary["words"].sum()),
              "rule": "exclude missing or negative word counts"}
    (output / "report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8")
    fig, ax = plt.subplots()
    ax.bar(summary.index, summary["words"])
    ax.set(xlabel="Category", ylabel="Words", title="Sample document totals")
    fig.tight_layout()
    fig.savefig(output / "summary.png", dpi=150)
    plt.close(fig)

def main():
    source = read_records()
    clean = clean_records(source)
    summary = summarize(clean)
    save_results(summary, len(clean), Path("results"))
    print(summary)
    print("excluded records:", len(source) - len(clean))

if __name__ == "__main__":
    main()
