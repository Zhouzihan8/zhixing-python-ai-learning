points=[0,1,9,10]
centers=[0,10]
print([min(range(2),key=lambda i: abs(x-centers[i])) for x in points])
