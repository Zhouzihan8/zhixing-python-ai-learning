from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
X,y=load_iris(return_X_y=True)
z=StandardScaler().fit_transform(X)
groups=KMeans(n_clusters=3,n_init=10,random_state=7).fit_predict(z)
projection=PCA(n_components=2).fit(z)
print("轮廓系数",silhouette_score(z,groups))
print("前两维方差比例",projection.explained_variance_ratio_)
print("二维坐标",projection.transform(z)[:3])
