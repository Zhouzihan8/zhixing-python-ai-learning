labels=[0,0,0,1]
predictions=[0]*len(labels)
correct=sum(p==y for p,y in zip(predictions,labels))
print(correct/len(labels))