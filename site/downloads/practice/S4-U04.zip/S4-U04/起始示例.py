tokens=[[1,2,3,4],[5,6,7,8]]
heads=[[row[:2] for row in tokens],[row[2:] for row in tokens]]
merged=[heads[0][t]+heads[1][t] for t in range(2)]
print(heads)
print(merged == tokens)