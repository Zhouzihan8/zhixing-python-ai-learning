from math import sqrt

def cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = sqrt(sum(x * x for x in a))
    nb = sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0

query = [1.0, 0.0]
docs = [("列表复制", [1.0, 0.0]), ("循环", [0.0, 1.0])]
ranked = sorted(docs, key=lambda item: cosine(query, item[1]), reverse=True)
for title, vector in ranked:
    print(title, f"{cosine(query, vector):.2f}")
