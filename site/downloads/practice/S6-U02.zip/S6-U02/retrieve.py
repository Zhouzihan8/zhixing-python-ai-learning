"""真实 embedding 检索。首次运行下载模型；不是规则相似度演示。"""
import argparse
import json
import platform
from pathlib import Path
import importlib.metadata
from sentence_transformers import SentenceTransformer

parser = argparse.ArgumentParser()
parser.add_argument("query", nargs="?", default="为什么修改复制出来的内层列表会影响原列表？")
parser.add_argument("--model", default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
parser.add_argument("--top-k", type=int, default=2)
args = parser.parse_args()
if args.top_k < 1:
    parser.error("--top-k must be positive")
root = Path(__file__).resolve().parent
documents = json.loads((root / "documents.json").read_text(encoding="utf-8"))
# 这个多语言模型未要求 query/document 前缀，教学语料都很短。
# 若更换为带特定提示/查询编码要求的模型，应按其模型卡调整，不能机械照搬。
model = SentenceTransformer(args.model, device="cpu")
vectors = model.encode([doc["text"] for doc in documents], normalize_embeddings=True)
query_vector = model.encode([args.query], normalize_embeddings=True)[0]
scores = vectors @ query_vector
indices = scores.argsort()[::-1][:min(args.top_k, len(documents))]
hits = [
    {"id": documents[int(i)]["id"], "source": documents[int(i)]["source"],
     "text": documents[int(i)]["text"], "score": float(scores[int(i)])}
    for i in indices
]
result = {
    "query": args.query, "model": args.model, "mode": "real_embedding_retrieval",
    "python": platform.python_version(),
    "sentence_transformers": importlib.metadata.version("sentence-transformers"),
    "hits": hits,
}
(root / "retrieval_result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
)
print("问题:", args.query)
for hit in hits:
    print(f"{hit['score']:.4f} [{hit['id']}] {hit['text']}")
    print("来源:", hit["source"])
print("已保存 retrieval_result.json；这只是检索结果，尚未生成模型答案。")
