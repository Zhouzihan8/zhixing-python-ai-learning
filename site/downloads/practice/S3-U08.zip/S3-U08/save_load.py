import json
from pathlib import Path
import torch

torch.manual_seed(7)
model = torch.nn.Linear(2, 1)
x = torch.tensor([[1., 2.], [3., 4.]])
model.eval()
with torch.no_grad():
    expected = model(x).clone()
out = Path("results")
out.mkdir(exist_ok=True)
torch.save(model.state_dict(), out / "weights.pt")
config = {"input_features": 2, "output_features": 1,
          "seed": 7, "torch_version": torch.__version__}
(out / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
config = json.loads((out / "config.json").read_text(encoding="utf-8"))
# A new object reconstructs architecture, then receives saved parameter values.
restored = torch.nn.Linear(config["input_features"], config["output_features"])
restored.load_state_dict(torch.load(out / "weights.pt",
                                   map_location="cpu", weights_only=True))
restored.eval()
with torch.no_grad():
    actual = restored(x)
print("before:\n", expected)
print("after:\n", actual)
print("equal:", torch.allclose(expected, actual))
assert torch.allclose(expected, actual)
