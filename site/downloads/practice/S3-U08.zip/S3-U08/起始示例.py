import json
from pathlib import Path
state={'weight':2.0,'bias':1.0,'input':'one number'}
f=Path('model_state.json')
f.write_text(json.dumps(state),encoding='utf-8')
loaded=json.loads(f.read_text(encoding='utf-8'))
print(loaded['weight']*3+loaded['bias'])