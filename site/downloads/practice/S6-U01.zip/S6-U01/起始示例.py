import json

status = 200
body = '{"answer": "先理解列表，再使用切片。"}'
if status == 200:
    result = json.loads(body)
    print(result["answer"])
else:
    print("请求失败:", status)
