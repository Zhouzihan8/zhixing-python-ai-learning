"""本地 HTTP 协议实验；返回的是规则回显，不是模型回答。"""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/echo":
            self.send_error(404, "Use /echo")
            return
        try:
            payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            question = payload["question"]
            if not isinstance(question, str):
                raise ValueError("question must be a string")
        except (json.JSONDecodeError, KeyError, ValueError) as error:
            status, result = 400, {"error": str(error)}
        else:
            status, result = 200, {"answer": "收到：" + question, "mode": "local_echo"}
        data = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

if __name__ == "__main__":
    print("本地回显服务：http://127.0.0.1:8766/echo；Ctrl+C 停止", flush=True)
    HTTPServer(("127.0.0.1", 8766), Handler).serve_forever()
