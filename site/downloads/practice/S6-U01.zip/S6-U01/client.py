"""真实发送本地 HTTP 请求；不需要第三方库或账号。"""
import json
import sys
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

question = " ".join(sys.argv[1:]) or "列表复制为何仍共享内部对象？"
payload = {"question": question}
request = Request(
    "http://127.0.0.1:8766/echo",
    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
    headers={"Content-Type": "application/json"},
    method="POST",
)
try:
    with urlopen(request, timeout=5) as response:
        result = json.loads(response.read().decode("utf-8"))
        print("HTTP 状态:", response.status)
        print("答案字段:", result["answer"])
        print("服务模式:", result["mode"])
except HTTPError as error:
    print("HTTP 错误:", error.code, error.read().decode("utf-8"))
except URLError as error:
    print("连接失败，请先运行 server.py:", error.reason)
