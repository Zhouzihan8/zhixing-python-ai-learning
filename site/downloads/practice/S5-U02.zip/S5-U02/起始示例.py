vocab={'learn':0,'python':1,'<unk>':2}
words='learn python learn'.split()
ids=[vocab.get(w,2) for w in words]
print(ids)
print('batch shape', (1,len(ids)))