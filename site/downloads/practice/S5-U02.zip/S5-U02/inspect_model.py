import json
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"
# Teaching model primarily supports English; use English to isolate interface learning.
torch.manual_seed(7)
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
# Default local device is CPU; .float() makes subsequent CPU operations float32.
model = AutoModelForCausalLM.from_pretrained(MODEL_ID).float().cpu()
model.eval()
if tokenizer.pad_token_id is None:
    tokenizer.pad_token = tokenizer.eos_token

def encode_question(text):
    messages = [{"role": "user", "content": text}]
    # Template inserts the model's role/special markers.
    rendered = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    # Do not add a second set of special tokens after rendering the template.
    batch = tokenizer(rendered, return_tensors="pt", add_special_tokens=False)
    return rendered, batch

def generate_answer(text, max_new_tokens=32, **sampling):
    _, batch = encode_question(text)
    with torch.inference_mode():
        output = model.generate(
            **batch, max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.pad_token_id, **sampling
        )
    # The returned sequence includes the prompt: decode only the new suffix.
    suffix = output[0, batch["input_ids"].shape[-1]:]
    return tokenizer.decode(suffix, skip_special_tokens=True)

question = "Explain what a Python list is in one short sentence."
rendered, batch = encode_question(question)
print("model:", MODEL_ID)
print("resolved model commit:", getattr(model.config, "_commit_hash", None))
print("template text:\n", rendered)
print("input_ids shape:", tuple(batch["input_ids"].shape))
print("attention_mask:", batch["attention_mask"].tolist())
print("token count:", batch["input_ids"].shape[-1])
print("hidden_size:", model.config.hidden_size)
print("answer:", generate_answer(question, do_sample=False))
