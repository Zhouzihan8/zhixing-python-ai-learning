import math
x=[1.0,2.0,3.0]
branch=[0.5,0.0,-0.5]
y=[a+b for a,b in zip(x,branch)]
m=sum(y)/len(y)
v=sum((a-m)**2 for a in y)/len(y)
print(y)
print([round((a-m)/math.sqrt(v+1e-5),4) for a in y])