import argparse
from copy import deepcopy
import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader, TensorDataset

def make_data(count, seed):
    generator = torch.Generator().manual_seed(seed)
    x = torch.randn(count, 2, generator=generator)
    y = (x[:, 0] + 0.3 * x[:, 1] > 0).long()
    return TensorDataset(x, y)

def evaluate(model, loader, loss_fn):
    model.eval()
    total_loss, correct, count = 0.0, 0, 0
    with torch.no_grad():
        for x, y in loader:
            logits = model(x)
            loss = loss_fn(logits, y)
            total_loss += loss.item() * len(y)
            correct += (logits.argmax(dim=1) == y).sum().item()
            count += len(y)
    return {"loss": total_loss / count, "accuracy": correct / count}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lr", type=float, default=0.1)
    args = parser.parse_args()
    torch.manual_seed(7)
    torch.set_num_threads(1)
    # Distinct generator seeds produce separate samples, with a shared label rule.
    train_data = make_data(48, 101)
    valid_data = make_data(24, 202)
    test_data = make_data(24, 303)
    train_loader = DataLoader(train_data, batch_size=10, shuffle=True,
                              generator=torch.Generator().manual_seed(404))
    valid_loader = DataLoader(valid_data, batch_size=10)
    test_loader = DataLoader(test_data, batch_size=10)
    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr)
    loss_fn = torch.nn.CrossEntropyLoss()
    best_loss, best_state, history = float("inf"), None, []
    for epoch in range(25):
        model.train()
        train_sum, train_count = 0.0, 0
        for x, y in train_loader:
            optimizer.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            optimizer.step()
            train_sum += loss.item() * len(y)
            train_count += len(y)
        valid = evaluate(model, valid_loader, loss_fn)
        history.append({"epoch": epoch + 1,
                        "train_loss": train_sum / train_count,
                        "valid_loss": valid["loss"],
                        "valid_accuracy": valid["accuracy"]})
        if valid["loss"] < best_loss:
            best_loss = valid["loss"]
            best_state = deepcopy(model.state_dict())
        print(epoch + 1, history[-1])
    model.load_state_dict(best_state)
    # Test only once, after validation has selected the checkpoint.
    final_test = evaluate(model, test_loader, loss_fn)
    out = Path("results")
    out.mkdir(exist_ok=True)
    torch.save(best_state, out / "best.pt")
    report = {"config": {"lr": args.lr, "epochs": 25,
                         "split_seeds": [101, 202, 303]},
              "history": history, "test": final_test}
    (out / "history.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Selected model test:", final_test)

if __name__ == "__main__":
    main()
