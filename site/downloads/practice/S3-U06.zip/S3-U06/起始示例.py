batch_results=[(2,2),(1,3)]
correct=sum(ok for ok,total in batch_results)
count=sum(total for ok,total in batch_results)
print(correct/count)
print(sum(ok/total for ok,total in batch_results)/len(batch_results))