def total(*values):
    return sum(values)
items = [2, 3, 4]
print(total(*items))
options = {'sep': ' / '}
print('Python', 'AI', **options)