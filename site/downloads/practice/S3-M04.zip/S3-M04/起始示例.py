tp,fp,fn=3,1,2
print(round(tp/(tp+fp),3),round(tp/(tp+fn),3))
