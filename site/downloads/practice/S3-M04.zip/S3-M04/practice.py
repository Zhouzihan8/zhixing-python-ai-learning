from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split,StratifiedKFold,GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,confusion_matrix
X,y=load_iris(return_X_y=True)
a,b,c,d=train_test_split(X,y,stratify=y,random_state=7)
pipe=make_pipeline(StandardScaler(),LogisticRegression(max_iter=500))
search=GridSearchCV(pipe,{"logisticregression__C":[0.1,1,10]},
 cv=StratifiedKFold(3,shuffle=True,random_state=7),scoring="f1_macro")
search.fit(a,c)
pred=search.predict(b)
print(search.best_params_)
print(classification_report(d,pred,zero_division=0))
print(confusion_matrix(d,pred))
