rows = [[80, 90], [70, 85], [95, 88]]
print(len(rows), len(rows[0]))
print(rows[0][1])