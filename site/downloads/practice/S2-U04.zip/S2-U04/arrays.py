import numpy as np

scores = np.array([[80, 90, 70], [60, 85, 95]], dtype=np.float64)
print("shape / ndim / size:", scores.shape, scores.ndim, scores.size)
print("second column:", scores[:, 1])
print("reshape:", scores.reshape(3, 2))
view = scores[:, :2]
view[0, 0] = 100
print("view changed original:", scores[0, 0])
copied = scores.copy()
copied[0, 0] = -1
print("copy did not change original:", scores[0, 0])
print("shared storage:", np.shares_memory(scores, view))
assert scores.shape == (2, 3)
assert scores[0, 0] == 100
assert copied[0, 0] == -1
