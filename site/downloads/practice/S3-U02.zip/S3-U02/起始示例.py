batch=[[1.0,2.0],[3.0,4.0],[5.0,6.0]]
print('样本数',len(batch),'特征数',len(batch[0]))
print(batch[0])