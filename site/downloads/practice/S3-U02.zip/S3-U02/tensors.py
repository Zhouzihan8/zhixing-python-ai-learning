import torch

x = torch.tensor([[1., 2.], [3., 4.], [5., 6.]])
w = torch.tensor([[1., 0., 2.], [0., 1., 3.]])
print("input:", tuple(x.shape), x.dtype, x.device)
print("sum dim=0:", x.sum(dim=0))
print("sum dim=1:", x.sum(dim=1))
out = x @ w
print("output shape:", tuple(out.shape))
print("first output:", out[0])
print("one sample:", tuple(x[0].shape))
print("one-sample batch:", tuple(x[0:1].shape))
assert tuple(out.shape) == (3, 3)
assert torch.allclose(out[0], torch.tensor([1., 2., 8.]))
